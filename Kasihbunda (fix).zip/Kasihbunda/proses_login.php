<?php
session_start();
include 'koneksi.php';

$email    = $_POST['email'];
$password = $_POST['password'];

// cari user berdasarkan email
$query = mysqli_query($conn, "SELECT * FROM daftar WHERE email='$email'");
$data  = mysqli_fetch_assoc($query);

if ($data) {
    // cek password hash
    if (password_verify($password, $data['password'])) {

        // simpan session
        $_SESSION['login'] = true;
        $_SESSION['id'] = $data['id'];
        $_SESSION['email'] = $data['email'];
        $_SESSION['nama']  = $data['nama_lengkap'];
        $_SESSION['role'] = $data['role'];

        if ($data['role'] == 'user') {
            header("Location: pasien/dashboard_pasien.php");
            exit;
        } else if ($data['role'] == 'bidan') {
            header("Location: bidan/dashboard_bidan.php");
            exit;
        } else {
            header("Location: index.php");
            exit;
        }

    } else {
        echo "<script>
            alert('Password salah!');
            window.location='login.php';
        </script>";
    }
} else {
    echo "<script>
        alert('Email tidak terdaftar!');
        window.location='login.php';
    </script>";
}
?>