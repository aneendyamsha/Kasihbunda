<?php
echo password_hash("bidan123", PASSWORD_DEFAULT);