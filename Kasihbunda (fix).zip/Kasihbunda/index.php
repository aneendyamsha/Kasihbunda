<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasih Bunda | Layanan Ibu Hamil</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>

    <nav class="navbar">
        <div class="logo">Kasih<span>Bunda</span></div>
        <ul class="nav-links">
            <li><a href="#home">Home</a></li>
            <li><a href="#services">Layanan</a></li>
            <li><a href="#appointment">Janji Temu</a></li>

            <?php if (isset($_SESSION['login'])) { ?>
                <li>Halo, <strong><?= $_SESSION['nama']; ?></strong></li>

                <?php if ($_SESSION['role'] == 'bidan') { ?>
                    <li><a href="bidan/dashboard_bidan.php">Profil</a></li>
                <?php } else { ?>
                    <li><a href="pasien/dashboard_pasien.php">Profil</a></li>
                <?php } ?>

                <li><a href="logout.php">Logout</a></li>
            <?php } else { ?> 
                <li><a href="login.php">Masuk</a></li>
                <li><a href="daftar.php">Daftar</a></li>
            <?php } ?>
        </ul>

        <div class="burger">
            <div class="line1"></div>
            <div class="line2"></div>
            <div class="line3"></div>
        </div>
    </nav>

    <header id="home" class="hero">
        <div class="hero-text">
            <h1>Pendamping Setia di Setiap Langkah Kehamilan Anda</h1>
            <p>Layanan bidan profesional dengan sentuhan kasih sayang dan teknologi modern.</p>

            <?php if (!isset($_SESSION['login'])) { ?>
                <a href="login.php" class="btn">Masuk untuk Buat Janji</a>
            <?php } else { ?>
                <a href="#appointment" class="btn">Buat Janji Temu</a>
            <?php } ?>
        </div>
    </header>

    <section id="profil" class="profil">
    <h2>Profil Bidan Klinik</h2>
    <div class="profil-container">
        <div class="profil-card">
            <h3>Bidan Amelia Maurentia, A.Md.Keb</h3>
            <p><strong>Pengalaman:</strong> 5 tahun</p>
            <p><strong>Keahlian:</strong> Pemeriksaan kehamilan, persalinan normal, konsultasi laktasi</p>

            <h4>🕒 Jadwal Praktik</h4>
            <ul>
                <li>Senin – Jumat : 08.00 – 16.00</li>
                <li>Sabtu : 08.00 – 12.00</li>
            </ul>

            <h4>🚫 Hari Libur</h4>
            <ul>
                <li>Minggu</li>
                <li>Hari Libur Nasional</li>
            </ul>
        </div>
    </div>
</section>


    <section id="services" class="services">
        <h2>Layanan Unggulan</h2>
        <div class="service-container">
            <div class="service-card">
                <div class="icon">🤰</div>
                <h3>Pemeriksaan Kehamilan</h3>
                <p>Pemantauan rutin kesehatan ibu dan janin menggunakan USG dan alat modern.</p>
            </div>
            <div class="service-card">
                <div class="icon">👶</div>
                <h3>Persalinan Normal</h3>
                <p>Proses persalinan yang nyaman, minim trauma, dan penuh dukungan.</p>
            </div>
            <div class="service-card">
                <div class="icon">🧘</div>
                <h3>Yoga Hamil</h3>
                <p>Mempersiapkan fisik dan mental ibu untuk menghadapi proses persalinan.</p>
            </div>
        </div>
    </section>

    <section id="appointment" class="appointment">
        <div class="form-container">
            <h2>Reservasi Online</h2>

            <?php if (!isset($_SESSION['login'])) { ?>
                <p> Silahkan <a href="login.php">login</a> untuk melakukan reservasi.</p>
            <?php } else { ?>
                <form id="bookingForm">
                    <input type="text" placeholder="Nama Lengkap" required>
                    <input type="email" placeholder="Email" required>
                    <input type="date" required>
                    <select>
                        <option value="">Pilih Layanan</option>
                        <option value="checkup">Check-up Rutin</option>
                        <option value="yoga">Yoga Hamil</option>
                        <option value="consultation">Konsultasi Laktasi</option>
                    </select>
                    <button type="submit" class="btn">Kirim Pesanan</button>
                </form>
            <?php } ?>
        </div>
    </section>

<section class="edukasi">
    <div class="container">
        <h2>Edukasi Pasien</h2>
        <p>Berikut ini kumpulan artikel & sumber bermanfaat untuk kesehatan ibu dan janin ❤️</p>

        <?php
        // Array link edukasi
        $edukasiLinks = [
            [
                "title" => "Cara Mengatasi Stretch Mark Saat Kehamilan",
                "url"   => "https://share.google/NbFettCTNvWvbzfNr"
            ],
            [
                "title" => "Panduan Persalinan Normal",
                "url"   => "https://share.google/1QYqTPQOJcG3CEh9L"
            ],
            [
                "title" => "Cara Menyusui yang Baik",
                "url"   => "https://youtu.be/g9qUgeCRjAo?si=z9omVYS3WuV7YJdw"
            ],
            [
                "title" => "Makanan Sehat untuk Ibu Hamil",
                "url"   => "https://share.google/CcSDextjDk82kfQ0y"
            ],
            [
                "title" => "Yoga Hamil untuk Ibu",
                "url"   => "https://youtu.be/o0bcQUBbJbw?si=P-gbLKCt8XBlKbxd"
            ]
        ];
        ?>

        <div class="edukasi-links">
            <?php foreach ($edukasiLinks as $link): ?>
                <a href="<?= $link['url']; ?>" target="_blank">
                    <?= $link['title']; ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

    <footer class="footer">
  <div class="footer-top">
    <?php ; ?> Kasih Bunda: Mengantar Harapan Menjadi Kebahagiaan
  </div>

  <div class="footer-content">
    <!-- Kolom 1 -->
    <div class="footer-col">
      <h3>Kasih Bunda Clinic</h3>
      <p>
        Bidan Profesional yang Peduli & Siap<br>
        Mendampingi Setiap Ibu ❤️
      </p>
    </div>

    <!-- Kolom 2 -->
    <div class="footer-col">
      <h3>Hubungi</h3>
      <p>📞 0812-4567-8920</p>
      <p>📧 kasihbunda@gmail.com</p>
      <p>
        📍 Jl. Margonda Raya No. 100,<br>
        Pd. Cina, Beji, Kota Depok, Jawa Barat 16424,<br>
        Indonesia
      </p>
    </div>

    <!-- Kolom 3 -->
    <div class="footer-col">
      <h3>Follow Kami</h3>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
  </div>
</footer>

    <footer>
        <p>&copy; 2026 Bidan Sejahtera. Semua Hak Dilindungi.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>