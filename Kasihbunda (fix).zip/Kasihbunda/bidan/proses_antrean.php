<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'bidan') {
    header("Location: ../login.php");
    exit;
}

$id = $_GET['id'];

// set antrian ini selesai
mysqli_query($conn, "
    UPDATE reservasi 
    SET status='selesai', jam_selesai=NOW()
    WHERE id='$id'
");

// ambil tanggal antrian ini
$q = mysqli_query($conn, "SELECT tanggal, nomor_antrian FROM reservasi WHERE id='$id'");
$data = mysqli_fetch_assoc($q);

// set antrian berikutnya jadi proses
mysqli_query($conn, "
    UPDATE reservasi 
    SET status='proses', jam_masuk=NOW()
    WHERE tanggal='{$data['tanggal']}'
    AND nomor_antrian = {$data['nomor_antrian']} + 1
");

header("Location: antrean_pasien.php");
exit;