<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'bidan') {
    header("Location: ../login.php");
    exit;
}

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');

$query = mysqli_query($conn, "
    SELECT r.*, d.nama_lengkap 
    FROM reservasi r
    JOIN daftar d ON r.id_pasien = d.id
    WHERE r.tanggal = '$tanggal'
    ORDER BY r.nomor_antrian ASC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Antrian Pasien</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="bidan-header">
    <h2>Dashboard Bidan</h2>
</div>

<div class="bidan-container">

    <div class="sidebar">
        <h3>Kasih Bunda</h3>
        <a href="dashboard_bidan.php">Dashboard</a>
        <a href="rekam_medis.php">Rekam Medis</a>
        <a href="antrean_pasien.php" class="active">Antrean Pasien</a>
        <a href="../index.php">Beranda</a>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <div class="main-content">

        <div class="card">
    <div class="card-header">
        <h3 class="daftar-title">Daftar Antrian Pasien (<?= date('d-m-Y', strtotime($tanggal)); ?>)</h3>
    </div>

    <!-- 🔽 FORM PILIH TANGGAL DI SINI -->
    <form method="GET" style="margin: 10px 0;">
        <label>Pilih Tanggal: </label>
        <input type="date" name="tanggal" value="<?= $tanggal ?>">
        <button type="submit">Lihat</button>
    </form>

    <div class="table-responsive">
        <table class="antrian-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pasien</th>
                    <th>Layanan</th>
                    <th>Keluhan</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($query) == 0) : ?>
                    <tr>
                        <td colspan="6" align="center" class="empty-row">Belum ada antrian untuk hari ini.</td>
                    </tr>
                <?php else : ?>
                    <?php $no = 1; while ($row = mysqli_fetch_assoc($query)) : ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td class="fw-medium"><?= htmlspecialchars($row['nama_lengkap']); ?></td>
                        <td><?= htmlspecialchars($row['layanan']); ?></td>
                        <td><?= htmlspecialchars($row['keluhan']); ?></td>
                        <td>
                            <span class="badge status-<?= $row['status']; ?>">
                                <?= ucfirst($row['status']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
