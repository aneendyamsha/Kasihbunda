<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'bidan') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_POST['id'])) {
    header("Location: antrean_pasien.php");
    exit;
}

$id = $_POST['id'];

/* 1️⃣ Ambil data antrian yang sedang diproses */
$data = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT tanggal, nomor_antrian 
    FROM reservasi 
    WHERE id='$id' AND status='proses'
"));

if (!$data) {
    header("Location: antrean_pasien.php");
    exit;
}

$tanggal = $data['tanggal'];
$nomor   = $data['nomor_antrian'];

/* 2️⃣ Tandai pasien ini SELESAI + isi jam selesai */
mysqli_query($conn, "
    UPDATE reservasi 
    SET status='selesai', jam_selesai=NOW()
    WHERE id='$id'
");

/* 3️⃣ Aktifkan pasien berikutnya (nomor antrian selanjutnya) */
mysqli_query($conn, "
    UPDATE reservasi 
    SET status='proses'
    WHERE tanggal='$tanggal'
    AND nomor_antrian='".($nomor + 1)."'
    AND status='menunggu'
");

/* 4️⃣ Kembali ke halaman antrian */
header("Location: antrean_pasien.php");
exit;
