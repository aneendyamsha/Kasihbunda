<?php
session_start();

// proteksi halaman: hanya bidan
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'bidan') {
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Bidan</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>

<!-- HEADER -->
<div class="bidan-header">
    <h2>Dashboard Bidan</h2>
    <p>Halo, <?= $_SESSION['nama']; ?></p>
</div>

<!-- CONTAINER -->
<div class="bidan-container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h3>Kasih Bunda</h3>
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="rekam_medis.php">Rekam Medis</a>
        <a href="antrean_pasien.php">Antrean Pasien</a>
        <a href="../index.php">Beranda</a>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <div class="card">
            <h3>Selamat Datang, Bidan <strong><?= $_SESSION['nama']; ?></strong></li></h3>
            <p> 
                Silakan mengelola data rekam medis pasien dengan aman dan profesional.
            </p>
        </div>

        <div class="card">
            <h3>Akses Cepat</h3>
            <ul>
                <li>📋 Input & update rekam medis pasien</li>
                <li>👩‍⚕️ Lihat data pasien terdaftar</li>
            </ul>
        </div>

    </div>
</div>

</body>
</html>