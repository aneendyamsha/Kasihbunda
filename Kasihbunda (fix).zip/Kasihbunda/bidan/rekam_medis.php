<?php
session_start();
include '../koneksi.php';

// proteksi login bidan
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'bidan') {
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rekam Medis</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>

<!-- HEADER -->
<div class="bidan-header">
    <h2>Rekam Medis Pasien</h2>
    <p>Bidan: <?= $_SESSION['nama']; ?></p>
</div>

<div class="bidan-container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h3>Kasih Bunda</h3>
        <a href="dashboard_bidan.php">Dashboard</a>
        <a href="rekam_medis.php" class="active">Rekam Medis</a>
        <a href="antrean_pasien.php">Antrean Pasien</a>
        <a href="../index.php">Beranda</a>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <!-- FORM INPUT REKAM MEDIS -->
        <div class="card">
            <h3>Input Rekam Medis</h3>

            <form action="simpan_rekam.php" method="POST">

                <input type="hidden" name="bidan_id" value="<?= $_SESSION['id']; ?>">

                <label>Pasien</label>
                <select name="pasien_id" required>
                    <option value="">-- Pilih Pasien --</option>

                    <?php
                    $pasien = mysqli_query($conn, "
                        SELECT id, nama_lengkap 
                        FROM daftar 
                        WHERE role = 'user'
                        ORDER BY nama_lengkap ASC
                    ");

                    while ($p = mysqli_fetch_assoc($pasien)) {
                        echo "<option value='{$p['id']}'>{$p['nama_lengkap']}</option>";
                    }
                    ?>
                </select>

                <label>Tanggal Pemeriksaan</label>
                <input type="date" name="tanggal" required>

                <input type="text" name="usia_kehamilan" placeholder="Usia Kehamilan (minggu)">
                <input type="text" name="tekanan_darah" placeholder="Tekanan Darah (contoh: 120/80)">
                <input type="number" step="0.1" name="berat_badan" placeholder="Berat Badan (kg)">

                <textarea name="keluhan" placeholder="Keluhan Pasien"></textarea>
                <textarea name="tindakan" placeholder="Tindakan"></textarea>
                <textarea name="catatan" placeholder="Catatan Tambahan"></textarea>

                <button type="submit">Simpan Rekam Medis</button>
            </form>
        </div>

        <!-- DATA REKAM MEDIS -->
        <div class="card">
            <h3>Data Rekam Medis</h3>

            <table width="100%" cellpadding="10">
                <tr style="background:#f1f1f1">
                    <th>Tanggal</th>
                    <th>Nama Pasien</th>
                    <th>Usia Kehamilan</th>
                    <th>Tekanan Darah</th>
                    <th>Berat Badan (kg)</th>
                    <th>Keluhan</th>
                    <th>Tindakan</th>
                    <th>Catatan</th>
                </tr>

                <?php
                $data = mysqli_query($conn, "
                    SELECT r.*, d.nama_lengkap 
                    FROM rekam_medis r
                    JOIN daftar d ON r.pasien_id = d.id
                    ORDER BY r.tanggal DESC
                ");

                while ($row = mysqli_fetch_assoc($data)) {
                    echo "
                    <tr>
                        <td>{$row['tanggal']}</td>
                        <td>{$row['nama_lengkap']}</td>
                        <td>{$row['usia_kehamilan']}</td>
                        <td>{$row['tekanan_darah']}</td>
                        <td>{$row['berat_badan']}</td>
                        <td>{$row['keluhan']}</td>
                        <td>{$row['tindakan']}</td>
                        <td>{$row['catatan']}</td>
                    </tr>
                    ";
                }
                ?>
            </table>
        </div>

    </div>
</div>

</body>
</html>
