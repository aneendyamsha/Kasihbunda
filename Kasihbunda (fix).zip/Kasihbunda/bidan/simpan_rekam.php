<?php
include '../koneksi.php';

mysqli_query($conn, "
INSERT INTO rekam_medis
(pasien_id, bidan_id, tanggal, usia_kehamilan, tekanan_darah, berat_badan, keluhan, tindakan, catatan)
VALUES (
'{$_POST['pasien_id']}',
'{$_POST['bidan_id']}',
'{$_POST['tanggal']}',
'{$_POST['usia_kehamilan']}',
'{$_POST['tekanan_darah']}',
'{$_POST['berat_badan']}',
'{$_POST['keluhan']}',
'{$_POST['tindakan']}',
'{$_POST['catatan']}'
)
");

header("Location: rekam_medis.php");
