<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login | Kasih Bunda</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<section class="appointment">
    <div class="form-container">
        <h2>Login</h2>

        <form action="proses_login.php" method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>

            <button type="submit" class="btn">Login</button>
        </form>

        <p>Belum punya akun? <a href="daftar.php">Daftar</a></p>
    </div>
</section>

</body>
</html>
