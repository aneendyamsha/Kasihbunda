<?php
$conn = mysqli_connect("localhost", "root", "", "kasihbunda");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
