<?php
session_start();      // mulai session
session_unset();      // hapus semua data session
session_destroy();    // hancurkan session

header("Location: index.php"); // balik ke halaman utama
exit;