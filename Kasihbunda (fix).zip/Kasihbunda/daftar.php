<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar | Bidan Kasih Bunda</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<section class="appointment">
    <div class="form-container">
        <h2>Daftar Akun</h2>

        <form action="proses_daftar.php" method="POST">

            <input type="text" name="nik" placeholder="NIK" required>
            <input type="text" name="nama_lengkap" placeholder="Nama Lengkap" required>
            <input type="date" name="tanggal_lahir" required>
            <textarea name="alamat" placeholder="Alamat Lengkap" required></textarea>
            <input type="text" name="no_telp" placeholder="Nomor Telepon" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>

            <button type="submit" class="btn">Daftar</button>
        </form>

    </div>
</section>

</body>
</html>
