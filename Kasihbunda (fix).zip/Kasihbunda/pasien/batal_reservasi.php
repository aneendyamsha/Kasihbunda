<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$id_pasien = $_SESSION['id'];
$id_reservasi = $_GET['id'] ?? null;

if (!$id_reservasi) {
    header("Location: reservasi_pasien.php");
    exit;
}

/* PASTIKAN RESERVASI MILIK PASIEN YANG LOGIN */
$cek = mysqli_query($conn, "
    SELECT id FROM reservasi 
    WHERE id='$id_reservasi' 
    AND id_pasien='$id_pasien'
");

if (mysqli_num_rows($cek) == 0) {
    header("Location: reservasi_pasien.php");
    exit;
}

/* HAPUS RESERVASI */
mysqli_query($conn, "
    DELETE FROM reservasi 
    WHERE id='$id_reservasi'
");

header("Location: reservasi_pasien.php");
exit;
