<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$id_pasien = $_SESSION['id'];
$tanggal   = $_POST['tanggal'];
$layanan   = $_POST['layanan'];
$keluhan   = $_POST['keluhan'];

/* CEK APAKAH PASIEN SUDAH PUNYA ANTRIAN AKTIF */
$cek = mysqli_query($conn, "
    SELECT id FROM reservasi 
    WHERE id_pasien='$id_pasien'
");

if (mysqli_num_rows($cek) > 0) {
    echo "<script>
        alert('Anda sudah memiliki antrian aktif!');
        window.location='reservasi_pasien.php';
    </script>";
    exit;
}

/* HITUNG NOMOR ANTRIAN */
$qAntrian = mysqli_query($conn, "
    SELECT MAX(nomor_antrian) AS max_antrian
    FROM reservasi
    WHERE tanggal='$tanggal'
");

$data = mysqli_fetch_assoc($qAntrian);
$nomor = ($data['max_antrian']) ? $data['max_antrian'] + 1 : 1;

/* ===============================
   SET STATUS AWAL
   =============================== */
$status = ($nomor == 1) ? 'proses' : 'menunggu';

/* SIMPAN RESERVASI */
mysqli_query($conn, "
    INSERT INTO reservasi 
    (id_pasien, tanggal, layanan, keluhan, nomor_antrian, bidan, waktu, status)
    VALUES 
    ('$id_pasien', '$tanggal', '$layanan', '$keluhan', '$nomor', 'Amelia Maurentia A.Md.Keb', '08:00', 'menunggu')
");

/* KEMBALI KE HALAMAN RESERVASI */
header("Location: reservasi_pasien.php");
exit;