<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$pasien_id = $_SESSION['id'];

$data = mysqli_query($conn, "
    SELECT r.*
    FROM rekam_medis r
    WHERE r.pasien_id = '$pasien_id'
    ORDER BY r.tanggal DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rekam Medis</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="bidan-header">
    <h2>Rekam Medis</h2>
    <p><?= $_SESSION['nama']; ?></p>
</div>

<div class="bidan-container">

    <div class="sidebar">
        <h3>Kasih Bunda</h3>
        <a href="dashboard_pasien.php">Dashboard</a>
        <a href="reservasi_pasien.php">Reservasi Online</a>
        <a href="rekam_medis.php" class="active">Rekam Medis</a>
        <a href="edit_profile.php">Edit Profil</a>
        <a href="../index.php">Beranda</a>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <div class="main-content">

        <div class="card">
            <h3>Riwayat Rekam Medis</h3>

            <table>
                <tr>
                    <th>Tanggal</th>
                    <th>Usia Kehamilan</th>
                    <th>BB</th>
                    <th>TD</th>
                    <th>Keluhan</th>
                    <th>Tindakan</th>
                    <th>Catatan</th>
                </tr>

                <?php while ($row = mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td><?= $row['tanggal']; ?></td>
                    <td><?= $row['usia_kehamilan']; ?></td>
                    <td><?= $row['berat_badan']; ?> kg</td>
                    <td><?= $row['tekanan_darah']; ?></td>
                    <td><?= $row['keluhan']; ?></td>
                    <td><?= $row['tindakan']; ?></td>
                    <td><?= $row['catatan']; ?></td>
                </tr>
                <?php } ?>
            </table>

        </div>

    </div>
</div>

</body>
</html>
