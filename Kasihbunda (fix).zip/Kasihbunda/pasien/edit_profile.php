<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}


$id = $_SESSION['id'];

/* AMBIL DATA PASIEN */
$query = mysqli_query($conn, "SELECT * FROM daftar WHERE id='$id'");
$pasien = mysqli_fetch_assoc($query);

/* PROSES UPDATE */
if (isset($_POST['simpan'])) {
    $nama   = $_POST['nama_lengkap'];
    $tgl    = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];
    $telp   = $_POST['no_telp'];
    $email  = $_POST['email'];

    mysqli_query($conn, "
        UPDATE daftar SET
            nama_lengkap = '$nama',
            tanggal_lahir    = '$tgl',
            alamat       = '$alamat',
            no_telp      = '$telp',
            email        = '$email'
        WHERE id = '$id'
    ");

    header("Location: dashboard_pasien.php");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Profil | Kasih Bunda</title>
    <!-- GOOGLE FONT (SAMAIN DASHBOARD) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- HEADER -->
<div class="bidan-header">
    <h1>Bidan Kasih Bunda</h1>
    <p>Teman Keluarga</p>
</div>

<div class="bidan-container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h2 class="brand-name">Kasih Bunda</h2>
        <a href="dashboard_pasien.php">Dashboard</a>
        <a href="reservasi_pasien.php">Reservasi Online</a>
        <a href="rekam_pasien.php">Rekam Medis</a>
        <a href="edit_profile.php" class="active">Edit Profil</a>
        <a href="../index.php">Beranda</a>
        <a href="../logout.php">Logout</a>
    </div>

    <!-- KONTEN -->
    <div class="main-content">

        <div class="card">
            <h3>Edit Profil Pasien</h3>
            <p class="subtext">
                Perbarui data diri Anda agar pelayanan lebih optimal.
            </p>

            <form method="POST">
                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama_lengkap"
                       value="<?= $pasien['nama_lengkap']; ?>">
                </div>     

                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir"
                       value="<?= $pasien['tanggal_lahir']; ?>">
                </div>  

                <div class="form-group">
                    <label>Alamat</label>
                    <textarea name="alamat" required><?= $pasien['alamat']; ?></textarea>
                </div>

                <div class="form-group">
                    <label>No. Telepon</label>
                    <input type="text" name="no_telp"
                       value="<?= $pasien['no_telp']; ?>">
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email"
                       value="<?= $pasien['email']; ?>">
                </div>

                <button type="submit" name="simpan">
                    Simpan Perubahan
                </button>
            </form>
        </div>

    </div>
</div>

</body>
</html>
