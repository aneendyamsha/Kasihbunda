<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$id = $_SESSION['id'];

// ambil data pasien
$query = mysqli_query($conn, "SELECT * FROM daftar WHERE id='$id'");
$pasien = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pasien</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- HEADER -->
<div class="bidan-header">
    <h2>Bidan Kasih Bunda</h2>
    <p>Teman Keluarga</p>
</div>

<div class="bidan-container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h3>Kasih Bunda</h3>
        <a href="dashboard_pasien.php" class="active">Dashboard</a>
        <a href="reservasi_pasien.php">Reservasi Online</a>
        <a href="rekam_pasien.php">Rekam Medis</a>
        <a href="edit_profile.php">Edit Profil</a>
        <a href="../index.php">Beranda</a>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <!-- WELCOME -->
        <div class="card">
            <h3>Halo, <?= $pasien['nama_lengkap']; ?></h3>
            <p>
                Selamat datang di layanan Bidan Kasih Bunda.  
                Anda dapat melihat rekam medis dan memperbarui data diri Anda.
            </p>
        </div>

        <!-- DATA DIRI PASIEN -->
        <div class="card">
            <h3>Data Diri Pasien</h3>

            <table class="table-detail">
                <tr>
                    <td>Nama Lengkap</td>
                    <td>: <?= $pasien['nama_lengkap']; ?></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td>: <?= $pasien['tanggal_lahir']; ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>: <?= $pasien['alamat']; ?></td>
                </tr>
                <tr>
                    <td>No. Telepon</td>
                    <td>: <?= $pasien['no_telp']; ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>: <?= $pasien['email']; ?></td>
                </tr>
            </table>
        </div>

    </div>
</div>

</body>
</html>
