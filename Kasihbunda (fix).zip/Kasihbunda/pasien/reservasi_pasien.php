<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$id = $_SESSION['id'];

// ambil data pasien
$pasien = mysqli_fetch_assoc(mysqli_query(
    $conn,
    "SELECT * FROM daftar WHERE id='$id'"
));

// cek apakah pasien sudah punya reservasi
$cekAntrian = mysqli_query(
    $conn,
    "SELECT * FROM reservasi 
     WHERE id_pasien='$id' 
     ORDER BY id DESC 
     LIMIT 1"
);

$adaAntrian = mysqli_num_rows($cekAntrian) > 0;
$antrian = $adaAntrian ? mysqli_fetch_assoc($cekAntrian) : null;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Reservasi Online</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- HEADER -->
<div class="bidan-header">
    <h2>Bidan Kasih Bunda</h2>
    <p>Teman Keluarga</p>
</div>

<div class="bidan-container">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h3>Kasih Bunda</h3>
        <a href="dashboard_pasien.php">Dashboard</a>
        <a href="reservasi_pasien.php" class="active">Reservasi Online</a>
        <a href="rekam_pasien.php">Rekam Medis</a>
        <a href="edit_profile.php">Edit Profil</a>
        <a href="../index.php">Beranda</a>
        <a href="../logout.php" class="logout">Logout</a>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <!-- FORM RESERVASI -->
        <?php if (!$adaAntrian) { ?>
        <div class="card reservasi-container">
            <h3 style="text-align:center;">Reservasi Online</h3>
            <p style="text-align:center; font-size:13px; color:#777;">
                Silahkan isi form untuk melakukan reservasi
            </p>

            <form class="form-reservasi" method="POST" action="proses_reservasi.php">
                <input type="text" value="<?= $pasien['nama_lengkap']; ?>" disabled>
                <input type="email" value="<?= $pasien['email']; ?>" disabled>

                <input type="date" name="tanggal" required>

                <select name="layanan" required>
                    <option value="">Pilih Layanan</option>
                    <option value="Check-up">Check-up</option>
                    <option value="Konsultasi">Konsultasi</option>
                </select>

                <textarea name="keluhan" placeholder="Keluhan" required></textarea>

                <button type="submit" class="btn-kirim">
                    Reservasi
                </button>
            </form>
        </div>
        <?php } ?>

        <!-- ANTRIAN PASIEN -->
        <?php if ($adaAntrian) { ?>
        <div class="card antrian-card">
            <h3>Antrian Pasien</h3>

            <div class="antrian-detail">
                <p><b>Layanan:</b> <?= $antrian['layanan']; ?></p>
                <p><b>Tanggal:</b> <?= $antrian['tanggal']; ?></p>
                <p><b>Keluhan:</b> <?= $antrian['keluhan']; ?></p>
                <p><b>Bidan:</b> <?= $antrian['bidan']; ?></p>
                <p><b>Waktu:</b> <?= $antrian['waktu']; ?></p>
            </div>

            <div class="nomor-antrian-title">Nomor Antrian</div>
            <div class="nomor-antrian">
                <?= $antrian['nomor_antrian']; ?>
            </div>

            <div class="antrian-info">
                <span>
                    <?= $antrian['nomor_antrian'] - 1; ?> Sisa Antrian
                </span> 
                <span>
                    0 Peserta Dilayani
                </span>
            </div>

            <a href="batal_reservasi.php?id=<?= $antrian['id']; ?>" class="btn-batal" onclick="return confirm('Yakin ingin membatalkan reservasi?')">
                ✕ Batalkan
            </a>
        </div>
        <?php } ?>

    </div>
</div>

</body>
</html>