let dataAntrian = {}; // SIMPAN SEMUA ANTRIAN
let pasienDilayani = 0;

function buatAntrian() {
    const nama = document.getElementById("nama").value;
    const email = document.getElementById("email").value;
    const tanggal = document.getElementById("tanggal").value;
    const layanan = document.getElementById("layanan").value;
    const keluhan = document.getElementById("keluhan").value;

    if (!nama || !email || !tanggal || !layanan || !keluhan) {
        alert("Lengkapi semua data!");
        return;
    }

    // Jika tanggal belum ada → buat array
    if (!dataAntrian[tanggal]) {
        dataAntrian[tanggal] = [];
    }

    // Nomor antrian berdasarkan jumlah pasien di tanggal itu
    const nomor = "A" + (dataAntrian[tanggal].length + 1);

    // Tentukan bidan
    const hari = new Date(tanggal).getDay();
    const bidanList = ["Bidan Amel"];
    const bidan = bidanList[hari % bidanList.length];

    // Simpan pasien
    dataAntrian[tanggal].push({
        nama,
        layanan,
        keluhan,
        bidan,
        nomor,
        status: "menunggu"
    });

    tampilkanAntrian(tanggal);
}

function tampilkanAntrian(tanggal) {
    const daftar = dataAntrian[tanggal];
    const pasien = daftar[daftar.length - 1]; // pasien terakhir

    document.getElementById("outLayanan").innerText = pasien.layanan;
    document.getElementById("outTanggal").innerText = tanggal;
    document.getElementById("outKeluhan").innerText = pasien.keluhan;
    document.getElementById("outBidan").innerText = pasien.bidan;
    document.getElementById("outNomor").innerText = pasien.nomor;

    document.getElementById("outWaktu").innerText =
        pasien.nomor === "A1"
            ? "07:30"
            : "Setelah pasien sebelumnya selesai";

    // HITUNG SISA ANTRIAN
    const sisa = daftar.filter(p => p.status === "menunggu").length;

    document.getElementById("outSisa").innerText = sisa;
    document.getElementById("outDilayani").innerText = pasienDilayani;

    document.getElementById("antrianBox").style.display = "block";
}

function batalkan() {
    const tanggal = document.getElementById("outTanggal").innerText;

    if (!dataAntrian[tanggal]) return;

    // Hapus pasien terakhir
    dataAntrian[tanggal].pop();

    alert("Reservasi dibatalkan");

    if (dataAntrian[tanggal].length === 0) {
        document.getElementById("antrianBox").style.display = "none";
    } else {
        tampilkanAntrian(tanggal);
    }
}
