<?php
include 'koneksi.php';

$nik = $_POST['nik'];
$nama = $_POST['nama_lengkap'];
$tgl = $_POST['tanggal_lahir'];
$alamat = $_POST['alamat'];
$telp = $_POST['no_telp'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$query = mysqli_query($conn, "
    INSERT INTO daftar 
    (nik, nama_lengkap, tanggal_lahir, alamat, no_telp, email, password)
    VALUES
    ('$nik','$nama','$tgl','$alamat','$telp','$email','$password')
");

if ($query) {
    echo "<script>
        alert('Daftar berhasil!');
        window.location='login.php';
    </script>";
} else {
    echo mysqli_error($conn);
}
